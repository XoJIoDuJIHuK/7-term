from src.responses import Scheme


class LanguageOutScheme(Scheme):
    id: int
    name: str
    iso_code: str
